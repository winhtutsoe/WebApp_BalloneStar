jQuery.fn.validation = function(cfg) {
    cfg = cfg || {};
    cfg.type = cfg.type || "alphasInt";
    cfg.add = cfg.add || "";
    cfg.empty = cfg.empty || "si";
    cfg.ctrl = cfg.ctrl || "si";
    cfg.onError = typeof cfg.onError == "function" ? cfg.onError : function() { };
    cfg.onDone = typeof cfg.onDone == "function" ? cfg.onDone : function() { };
    this.keypress(function(e) {
        key = getKeyCode(e);
        cfg.OBJ = this;
        if (cfg.ctrl == "si") {
            if ((e.ctrlKey && key == 97) || (e.ctrlKey && key == 65)) return true;
            if ((e.ctrlKey && key == 120) || (e.ctrlKey && key == 88)) return true;
            if ((e.ctrlKey && key == 99) || (e.ctrlKey && key == 67)) return true;
            if ((e.ctrlKey && key == 122) || (e.ctrlKey && key == 90)) return true;
            if ((e.ctrlKey && key == 118) || (e.ctrlKey && key == 86) || (e.shiftKey && key == 45)) return true;
        } else {
            if ((e.ctrlKey && key == 97) || (e.ctrlKey && key == 65)) return false;
            if ((e.ctrlKey && key == 120) || (e.ctrlKey && key == 88)) return false;
            if ((e.ctrlKey && key == 99) || (e.ctrlKey && key == 67)) return false;
            if ((e.ctrlKey && key == 122) || (e.ctrlKey && key == 90)) return false;
            if ((e.ctrlKey && key == 118) || (e.ctrlKey && key == 86) || (e.shiftKey && key == 45)) return false;
        }
        if (key == undefined) return true;
        return validateChar(key);
    });
    this.blur(function() {
        if (cfg.empty == "no" && this.value.length == 0) {
            cfg.onError.apply(this);
            return false;
        }
        valid = 1;
        for (j = 0; j < this.value.length; j++)
            if (validateChar(this.value.charCodeAt(j)) != true) valid = 0;
        if (cfg.type == "mail" && this.value.length > 0) { valid = checkEmail(this.value); }
        if (valid == 0) cfg.onError.apply(this); else cfg.onDone.apply(this);
    });
    function validateChar(key) {
        //  backspace       enter
        if (key == 8 || key == 13) return true;
        if (cfg.add != "" && keyAdd(key, cfg.add)) return true;
        if (cfg.type == 'int') return keyN(key);
        else if (cfg.type == 'lower') return keyL(key);
        else if (cfg.type == 'lowers') return (keyL(key) || keyAdd(key, "������"));
        else if (cfg.type == 'upper') return keyU(key);
        else if (cfg.type == 'uppers') return (keyU(key) || keyAdd(key, "������"));
        else if (cfg.type == 'alpha') return (keyL(key) || keyU(key));
        else if (cfg.type == 'alphas') return (keyL(key) || keyU(key) || keyAdd(key, "������"));
        else if (cfg.type == 'lowerInt') return (keyL(key) || keyN(key));
        else if (cfg.type == 'lowersInt') return (keyL(key) || keyN(key) || keyAdd(key, "������"));
        else if (cfg.type == 'upperInt') return (keyU(key) || keyN(key));
        else if (cfg.type == 'uppersInt') return (keyU(key) || keyN(key) || keyAdd(key, "������"));
        else if (cfg.type == 'alphaInt') return (keyL(key) || keyU(key) || keyN(key));
        else if (cfg.type == 'alphasInt') return (keyL(key) || keyU(key) || keyN(key) || keyAdd(key, "������"));
        else if (cfg.type == 'nick') return (keyL(key) || keyU(key) || keyN(key) || keyAdd(key, "-_ .@"));
        else if (cfg.type == 'mail') return keyMail(key);
    }
    function getKeyCode(e) {
        if (window.event) return e.keyCode;
        else if (e.which) return e.which;
    }
    function keyAdd(key, add) {
        for (i = 0; i < add.length; i++)
            if (key == add.charCodeAt(i)) return true;
        return false;
    }
    function keyN(k) {
        return (k >= 48 && k <= 57)
    }
    function keyU(k) {
        return (k >= 65 && k <= 90);
    }
    function keyL(k) {
        return (k >= 97 && k <= 122)
    }
    function keyMail(k) {
        if (keyL(k) || keyU(k) || keyN(k) || keyAdd(k, "-_.@")) {
            if ((k == 46 || k == 45 || k == 95 || k == 64) && cfg.OBJ.value.length == 0) return false;
            if (keyN(k) && cfg.OBJ.value.length == 0) return false;
            if ((k == 46 || k == 45 || k == 95 || k == 64) && cfg.OBJ.value[cfg.OBJ.value.length - 1] == ".") return false;
            cb = cfg.OBJ.value[cfg.OBJ.value.length - 1];
            if ((k == 46 || k == 64) && (cb == "-" || cb == "_" || cb == "@" || cb == ".")) return false;
            if (k == 64 && cfg.OBJ.value.length < 3) return false;
            if (cfg.OBJ.value.indexOf("@") != -1) {
                if (k == 64) return false;
                offSet = cfg.OBJ.value.length - cfg.OBJ.value.indexOf("@");
                if ((k == 46 || k == 45 || k == 95) && offSet == 1) return false;
                if (k == 46 && offSet < 4) return false;
            }
        } else return false;
    }
    function db(s) { $("#test").html($("#test").html() + "<br>" + s + " - " + String.fromCharCode(s)); }
    function db1(s) { $("#test").html($("#test").html() + "<br>" + s); }
    function checkEmail(toCheck) {
        if (/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/.test(toCheck)) return true; else return false;
    }
}