﻿using System;
using Whizzo;
namespace BalloneStarcPanel.Entities
{
	public class NewsCategory 
	{
			
		#region Constructers

			public NewsCategory(){}

		#endregion
		
		#region Internal Members
		
					private	int _ID;
			private	string _NewsCategoryName;
			private	string _Status;

		
		#endregion
		
		#region Properties
		
					public	int  ID
			{
				get 
				{ 
					if(Null.IsNotNull(_ID)) 
					{
					 return _ID;
					}
					else 
					{
					 return 0;
					}
				}
				set { _ID = value;}
			}
			public	string  NewsCategoryName
			{
				get 
				{ 
					if(Null.IsNotNull(_NewsCategoryName)) 
					{
					 return _NewsCategoryName;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _NewsCategoryName = value;}
			}
			public	string  Status
			{
				get 
				{ 
					if(Null.IsNotNull(_Status)) 
					{
					 return _Status;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _Status = value;}
			}

		
		#endregion
		
		#region CustomCommand
			
			
			
			
		
		
		
		#endregion CustomCommand
		
	}
}