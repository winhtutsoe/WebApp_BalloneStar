﻿using System;
using Whizzo;
namespace BalloneStarcPanel.Entities
{
	public class News 
	{
			
		#region Constructers

			public News(){}

		#endregion
		
		#region Internal Members
		
					private	int _ID;
			private	int _NewsCategoryID;
			private	int _NewsTypeID;
			private	string _NewsCategoryName;
			private	string _NewTypeName;
			private	string _Description;
			private	string _HashTag;
			private	string _ImagePath;
			private	DateTime _ReleaseDate;
			private	string _Status;

		
		#endregion
		
		#region Properties
		
					public	int  ID
			{
				get 
				{ 
					if(Null.IsNotNull(_ID)) 
					{
					 return _ID;
					}
					else 
					{
					 return 0;
					}
				}
				set { _ID = value;}
			}
			public	int  NewsCategoryID
			{
				get 
				{ 
					if(Null.IsNotNull(_NewsCategoryID)) 
					{
					 return _NewsCategoryID;
					}
					else 
					{
					 return 0;
					}
				}
				set { _NewsCategoryID = value;}
			}
			public	int  NewsTypeID
			{
				get 
				{ 
					if(Null.IsNotNull(_NewsTypeID)) 
					{
					 return _NewsTypeID;
					}
					else 
					{
					 return 0;
					}
				}
				set { _NewsTypeID = value;}
			}
			public	string  NewsCategoryName
			{
				get 
				{ 
					if(Null.IsNotNull(_NewsCategoryName)) 
					{
					 return _NewsCategoryName;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _NewsCategoryName = value;}
			}
			public	string  NewTypeName
			{
				get 
				{ 
					if(Null.IsNotNull(_NewTypeName)) 
					{
					 return _NewTypeName;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _NewTypeName = value;}
			}
			public	string  Description
			{
				get 
				{ 
					if(Null.IsNotNull(_Description)) 
					{
					 return _Description;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _Description = value;}
			}
			public	string  HashTag
			{
				get 
				{ 
					if(Null.IsNotNull(_HashTag)) 
					{
					 return _HashTag;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _HashTag = value;}
			}
			public	string  ImagePath
			{
				get 
				{ 
					if(Null.IsNotNull(_ImagePath)) 
					{
					 return _ImagePath;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _ImagePath = value;}
			}
			public	DateTime  ReleaseDate
			{
				get 
				{ 
					if(Null.IsNotNull(_ReleaseDate)) 
					{
					 return _ReleaseDate;
					}
					else 
					{
					 return DateTime.Now;
					}
				}
				set { _ReleaseDate = value;}
			}
			public	string  Status
			{
				get 
				{ 
					if(Null.IsNotNull(_Status)) 
					{
					 return _Status;
					}
					else 
					{
					 return string.Empty;
					}
				}
				set { _Status = value;}
			}

		
		#endregion
		
		#region CustomCommand
			
			
			
		
		
		#endregion CustomCommand
		
	}
}