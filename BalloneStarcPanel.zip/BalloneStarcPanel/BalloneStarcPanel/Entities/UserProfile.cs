﻿using System;
using Whizzo;
namespace BalloneStarcPanel.Entities
{
    public class UserProfile
    {

        #region Constructers

        public UserProfile() { }

        #endregion

        #region Internal Members

        private int _ID;
        private string _UserName;
        private string _Password;
        private string _NRCNo;
        private string _Address;
        private string _Phone;
        private string _OTPKey;
        private string _ImageURL;
        private int _RoleID;
        private string _Status;

        #endregion

        #region Properties

        public int ID
        {
            get
            {
                if (Null.IsNotNull(_ID))
                {
                    return _ID;
                }
                else
                {
                    return 0;
                }
            }
            set { _ID = value; }
        }
        public string UserName
        {
            get
            {
                if (Null.IsNotNull(_UserName))
                {
                    return _UserName;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _UserName = value; }
        }
        public string Password
        {
            get
            {
                if (Null.IsNotNull(_Password))
                {
                    return _Password;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _Password = value; }
        }
        public string NRCNo
        {
            get
            {
                if (Null.IsNotNull(_NRCNo))
                {
                    return _NRCNo;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _NRCNo = value; }
        }
        public string Address
        {
            get
            {
                if (Null.IsNotNull(_Address))
                {
                    return _Address;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _Address = value; }
        }
        public string Phone
        {
            get
            {
                if (Null.IsNotNull(_Phone))
                {
                    return _Phone;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _Phone = value; }
        }
        public string OTPKey
        {
            get
            {
                if (Null.IsNotNull(_OTPKey))
                {
                    return _OTPKey;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _OTPKey = value; }
        }
        public string ImageURL
        {
            get
            {
                if (Null.IsNotNull(_ImageURL))
                {
                    return _ImageURL;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _ImageURL = value; }
        }
        public int RoleID
        {
            get
            {
                if (Null.IsNotNull(_RoleID))
                {
                    return _RoleID;
                }
                else
                {
                    return 0;
                }
            }
            set { _RoleID = value; }
        }
        public string Status
        {
            get
            {
                if (Null.IsNotNull(_Status))
                {
                    return _Status;
                }
                else
                {
                    return string.Empty;
                }
            }
            set { _Status = value; }
        }

        #endregion

    }
}


