﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Whizzo;
using BalloneStarcPanel.DataAccess;
using BalloneStarcPanel.Entities;
using Whizzo.Security;
namespace BalloneStarcPanel
{
    public partial class Login : System.Web.UI.Page
    {
        GoogleReCaptcha.GoogleReCaptcha ctrlGoogleReCaptcha = new GoogleReCaptcha.GoogleReCaptcha();

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            ctrlGoogleReCaptcha.PublicKey = "6LflPh4TAAAAAJ6E8pNREQcxElvWyNK7sUmeQajd";
            ctrlGoogleReCaptcha.PrivateKey = "6LflPh4TAAAAANVMh8uyTOztwJIPLWWD3fmC-HBh";
            this.Panel1.Controls.Add(ctrlGoogleReCaptcha);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            btnLogin.Click += new EventHandler(btnLogin_Click);

            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                    Response.Redirect(Config.GetConfig("mainURL") + "Default.aspx");
                }
            }
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {

            if (IsValidData())
            {
                if (ctrlGoogleReCaptcha.Validate())
                {
                    UserProfile user = new UserProfile();
                    UserProfileTableAdapter userTable = new UserProfileTableAdapter();
                    user = userTable.GetEmployeeByName(StringUtil.EncodeHtml(txtUserName.Text.Trim()), "ACTIVE");
                    if (user.ID > 0)
                    {
                        if (user.Password == Hash.ToHash(StringUtil.EncodeHtml(txtPassword.Text.Trim())))
                        {
                            Session["Login"] = user.ID;
                            Session["Name"] = user.UserName;
                            Session["Role"] = user.RoleID;
                            Response.Redirect(Config.GetConfig("mainURL") + "Default.aspx");
                        }
                        else
                        {
                            ShowErrorMessage(GetGlobalResourceObject("UserProfilesResource", "InvalidPassword").ToString());
                        }
                    }
                    else
                    {
                        ShowErrorMessage(GetGlobalResourceObject("UserProfilesResource", "EmailNotExit").ToString());
                    }
                }
                else
                {
                    ShowErrorMessage(GetGlobalResourceObject("UserProfilesResource", "CaptchaFail").ToString());
                }
            }
               
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
            if (Null.IsNull(txtUserName.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireUserName").ToString();
                validData = false;
            }
            if (Null.IsNull(txtPassword.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequirePassword").ToString();
                validData = false;
            }
            if (!validData)
            {
                ShowErrorMessage(error);
            }

            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag").ToString();
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag").ToString();
        }
    }
}
