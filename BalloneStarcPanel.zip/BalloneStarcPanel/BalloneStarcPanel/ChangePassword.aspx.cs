﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Whizzo;
using Whizzo.Security;
using BalloneStarcPanel.DataAccess;
using BalloneStarcPanel.Entities;

namespace BalloneStarcPanel
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {

                DataSet ds = new DataSet();
                UserProfileTableAdapter userTable = new UserProfileTableAdapter();
                if (Session["Role"].ToString() == "1")
                {
                    ds = userTable.GetEmployeeByStatus("ACTIVE");
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        ddlUserName.DataTextField = "UserName";
                        ddlUserName.DataValueField = "ID";
                        ddlUserName.DataSource = ds.Tables[0];
                        ddlUserName.DataBind();
                    }
                }
                else
                {
                    ddlUserName.Items.Add(Session["Name"].ToString());
                    ddlUserName.Enabled = false;
                    ddlUserName.DataBind();
                }

            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                    UserProfileTableAdapter userTable = new UserProfileTableAdapter();
                    UserProfile user = new UserProfile();
                    user = userTable.GetEmployeeByName(ddlUserName.SelectedItem.ToString(), "ACTIVE");
                    string oldPassword = Hash.ToHash(StringUtil.EncodeHtml(txtOldPassword.Text.Trim()));
                    string newPassword = Hash.ToHash(StringUtil.EncodeHtml(txtNewPassword.Text.Trim()));
                    if (oldPassword.Equals(QueryString.Decode(user.Password)))
                    {

                        user.Password = newPassword;
                        if (userTable.Update(user) > 0)
                        {
                            Session["Login"] = null;
                            Session["Name"] = null;
                            Session.Clear();
                            Response.Redirect("Login.aspx");
                        }
                    }
                    else
                    {
                        ShowErrorMessage(GetGlobalResourceObject("UserProfilesResource", "InvalidOldPassword").ToString());
                    }
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(Config.GetConfig("mainURL") + "Default");
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
            if (Null.IsNull(txtOldPassword.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireOldPassword").ToString();
                validData = false;
            }
            if (Null.IsNull(txtNewPassword.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireNewPassword").ToString();
                validData = false;
            }
            if (Null.IsNull(txtConfirmPassword.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireConfirmPassword").ToString();
                validData = false;
            }
            if (!StringUtil.EncodeHtml(txtNewPassword.Text.Trim()).Equals(StringUtil.EncodeHtml(txtConfirmPassword.Text.Trim())))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "NotSameNewPassword").ToString();
                validData = false;
            }
            if (!validData)
            {
                ShowErrorMessage(error);
            }
            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag");
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag");
        }
    }
}
