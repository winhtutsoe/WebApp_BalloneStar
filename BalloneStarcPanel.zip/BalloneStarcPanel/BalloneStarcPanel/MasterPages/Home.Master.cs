﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Whizzo;
namespace BalloneStarcPanel.MasterPages
{
    public partial class Home : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Null.IsNull(Session["Login"]) || Null.IsNull(Session["Role"]))
            {
                Response.Redirect("~/Login.aspx");
            }
        }
    }
}
