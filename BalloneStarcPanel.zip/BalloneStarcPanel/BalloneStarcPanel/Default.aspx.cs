﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Whizzo;
using System.Data;

namespace BalloneStarcPanel
{
    public partial class Default : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Request["q"]))
                {
                    if (Null.IsNotNull(Session["Login"].ToString()))
                    {
                        Session["Login"] = null;
                        Session["Name"] = null;
                        Response.Redirect("~/login.aspx");
                    }
                }
                else
                {
                    DataSet ds = new DataSet();
                    string filepath = Server.MapPath("~/LeftNav.xml");
                    ds.ReadXml(filepath);
                    if (Null.IsNotNull(Session["Login"]))
                    {
                        Response.Redirect(ds.Tables["Item"].Rows[0]["url"].ToString() + "?GroupID=" + Request["GroupID"]);
                    }
                    else
                    {
                        Response.Redirect("~/login.aspx");
                        Session["Login"] = null;
                        Session["Name"] = null;
                    }
                }
            }
        }
    }
}
