﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Whizzo;

namespace BalloneStarcPanel.Controls
{
    public partial class LeftNav : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DataSet ds = new DataSet();
                string filepath = Server.MapPath("~/LeftNav.xml");
                ds.ReadXml(filepath);
                if (Null.IsNotNull(Session["Login"]))
                {
                    int i = 0; int j = 0;
                    if (Null.IsNull(Request["GroupID"]))
                    {
                        while (i < ds.Tables["Group"].Rows.Count && j < Convert.ToInt32(ds.Tables["Item"].Rows[i].Table.Rows.Count))
                        {
                            if (j == 0)
                            {
                                ltlLeftNav.Text += "<li class=\"has-sub\"><a href='#' class=''><i class='" + ds.Tables["Group"].Rows[i]["GroupImg"].ToString() + "'></i>" + ds.Tables["Group"].Rows[i]["GroupName"].ToString() + " <span class='arrow'></span></a><ul class=\"sub\">";
                            }
                            else if (!ds.Tables["Item"].Rows[i].Table.Rows[j]["Group_Id"].Equals(ds.Tables["Item"].Rows[i].Table.Rows[j - 1]["Group_Id"]))
                            {
                                i++;
                                ltlLeftNav.Text += "</ul></li>";
                                ltlLeftNav.Text += "<li class=\"has-sub\"><a href='#' class=''><i class='" + ds.Tables["Group"].Rows[i]["GroupImg"].ToString() + "'></i>" + ds.Tables["Group"].Rows[i]["GroupName"].ToString() + " <span class='arrow'></span></a><ul class=\"sub\">";
                            }
                            if (Session["Role"].ToString() == "1")
                            {
                                ltlLeftNav.Text += "<li><a class='' href='" + ds.Tables["Item"].Rows[j]["url"].ToString() + "?GroupID=" + Encode(ds.Tables["Group"].Rows[i]["Group_Id"]) + "'>" + ds.Tables["Item"].Rows[j]["title"].ToString() + "</a></li>";
                            }
                            else
                            {
                                if (ds.Tables["Item"].Rows[j]["Role"].ToString() == "All")
                                {
                                    ltlLeftNav.Text += "<li><a class='' href='" + ds.Tables["Item"].Rows[j]["url"].ToString() + "?GroupID=" + Encode(ds.Tables["Group"].Rows[i]["Group_Id"]) + "'>" + ds.Tables["Item"].Rows[j]["title"].ToString() + "</a></li>";
                                }
                            }

                            if (j + 1 == Convert.ToInt32(ds.Tables["Item"].Rows[i].Table.Rows.Count))
                            {
                                ltlLeftNav.Text += "</ul></li>";
                            }
                            j++;
                        }
                    }
                    else
                    {
                        int GroupID = Convert.ToInt32(QueryString.Decode(Request["GroupID"]));
                        ltlLeftNav.Text = null;
                        ltlLeftNav.Text = GetLeftNav(ds, GroupID);
                    }
                }
            }
        }
        public string Encode(object query)
        {
            return QueryString.Encode(query.ToString());
        }
        public string GetLeftNav(DataSet ds, int groupID)
        {
            int i = 0; int j = 0; string str = null;
            if (Null.IsNull(ltlLeftNav.Text))
            {
                while (i < ds.Tables["Group"].Rows.Count && j < Convert.ToInt32(ds.Tables["Item"].Rows[i].Table.Rows.Count))
                {
                    if (j == 0)
                    {
                        if (groupID == 0)
                        {
                            str += "<li class=\"has-sub active\"><a href='" + ds.Tables["Item"].Rows[j]["url"].ToString() + "?GroupID=" + Encode(ds.Tables["Group"].Rows[i]["Group_Id"]) + "' class=''><i class='" + ds.Tables["Group"].Rows[i]["GroupImg"].ToString() + "'></i>" + ds.Tables["Group"].Rows[i]["GroupName"].ToString() + " <span class='arrow open'></span><span class='selected'></span></a><ul class=\"sub\">";
                        }
                        else
                        {
                            str += "<li class=\"has-sub\"><a href='#' class=''><i class='" + ds.Tables["Group"].Rows[i]["GroupImg"].ToString() + "'></i>" + ds.Tables["Group"].Rows[i]["GroupName"].ToString() + " <span class='arrow'></span></a><ul class=\"sub\">";
                        }
                    }
                    else if (!ds.Tables["Item"].Rows[i].Table.Rows[j]["Group_Id"].Equals(ds.Tables["Item"].Rows[i].Table.Rows[j - 1]["Group_Id"]))
                    {
                        i++;
                        str += "</ul></li>";
                        if (i == groupID)
                        {
                            str += "<li class=\"has-sub active\"><a href='" + ds.Tables["Item"].Rows[j]["url"].ToString() + "?GroupID=" + Encode(ds.Tables["Group"].Rows[i]["Group_Id"]) + "' class=''><i class='" + ds.Tables["Group"].Rows[i]["GroupImg"].ToString() + "'></i>" + ds.Tables["Group"].Rows[i]["GroupName"].ToString() + " <span class='arrow open'></span><span class='selected'></span></a><ul class=\"sub\">";
                        }
                        else
                        {
                            str += "<li class=\"has-sub\"><a href='#' class=''><i class='" + ds.Tables["Group"].Rows[i]["GroupImg"].ToString() + "'></i>" + ds.Tables["Group"].Rows[i]["GroupName"].ToString() + " <span class='arrow'></span></a><ul class=\"sub\">";
                        }
                    }
                    if (Session["Role"].ToString() == "1")
                    {
                        str += "<li><a class='' href='" + ds.Tables["Item"].Rows[j]["url"].ToString() + "?GroupID=" + Encode(ds.Tables["Group"].Rows[i]["Group_Id"]) + "'>" + ds.Tables["Item"].Rows[j]["title"].ToString() + "</a></li>";

                    }
                    else
                    {
                        if (ds.Tables["Item"].Rows[j]["Role"].ToString() == "All")
                        {
                            str += "<li><a class=''href='" + ds.Tables["Item"].Rows[j]["url"].ToString() + "?GroupID=" + Encode(ds.Tables["Group"].Rows[i]["Group_Id"]) + "'>" + ds.Tables["Item"].Rows[j]["title"].ToString() + "</a></li>";
                        }
                    }
                    if (j + 1 == Convert.ToInt32(ds.Tables["Item"].Rows[i].Table.Rows.Count))
                    {
                        str += "</ul></li>";
                    }
                    j++;
                }
            }
            return str;
        }
    }
}