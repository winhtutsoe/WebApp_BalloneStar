﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Whizzo;
namespace BalloneStarcPanel.Controls
{
    public partial class Header : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]))
                {
                    ltlUserName.Text = Session["Name"].ToString();
                    ltlLink.Text += "<li><a href='../ChangePassword.aspx'><i class='icon-key'></i>Change Password</a></li>";
                    ltlLink.Text += "<li><a href='../UserProfiles/Default.aspx?q=logout'><i class='icon-share'></i>Log Out</a></li>";
                    if (Null.IsNotNull(Request["q"]))
                    {
                        if (Null.IsNotNull(Session["Login"].ToString()))
                        {
                            Session["Login"] = null;
                            Session["Name"] = null;
                            Session["Role"] = null;
                            Response.Redirect("~/login.aspx");
                        }
                    }
                }
            }
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
    }
}