﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Whizzo;
using BalloneStarcPanel.Entities;
using BalloneStarcPanel.DataAccess;
using Whizzo.Security;
namespace BalloneStarcPanel.NewsTypes
{
    public partial class NewNewsType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                  
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
				NewsTypeTableAdapter newsTypeTableAdapter = new NewsTypeTableAdapter();
NewsType newsType = new NewsType();
newsType.NewsTypeName = StringUtil.EncodeHtml(txtNewTypeName.Text.Trim());
newsType.Status = "ACTIVE";
if (newsTypeTableAdapter.Insert(newsType) > 0)
{
Response.Redirect("~/NewsTypes/Default.aspx?GroupID=" + Request["GroupID"]);
}

            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("../NewsTypes/Default.aspx?GroupID=" + Request["GroupID"]);
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
            if (Null.IsNull(txtNewTypeName.Text.Trim()))
{
error += GetGlobalResourceObject("NewsTypesResource", "RequireNewTypeName").ToString();
validData = false;
}


            if (!validData)
            {
                ShowErrorMessage(error);
            }
            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag").ToString();
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag").ToString();
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
    }
}
