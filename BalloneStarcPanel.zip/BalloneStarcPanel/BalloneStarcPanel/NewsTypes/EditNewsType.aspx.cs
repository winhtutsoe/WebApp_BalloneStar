﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Whizzo;
using BalloneStarcPanel.Entities;
using BalloneStarcPanel.DataAccess;
namespace BalloneStarcPanel.NewsTypes
{
    public partial class EditNewsType : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {


                    NewsTypeTableAdapter newsTypeTableAdapter = new NewsTypeTableAdapter();
                    NewsType newsType = new NewsType();
                    newsType = newsTypeTableAdapter.GetNewsTypeByID(Convert.ToInt32(QueryString.Decode(Request["NewsTypeID"])));
                    txtNewTypeName.Text = newsType.NewsTypeName;


                }
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {

                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                    if (Validation.IsNumber(QueryString.Decode(Request["NewsTypeID"])) && Null.IsNotNull(Session["Login"]))
                    {
                        NewsTypeTableAdapter newsTypeTableAdapter = new NewsTypeTableAdapter();
                        NewsType newsType = new NewsType();
                        newsType.ID = Convert.ToInt32(QueryString.Decode(Request["NewsTypeID"].ToString()));
                        newsType.NewsTypeName = StringUtil.EncodeHtml(txtNewTypeName.Text.Trim());
                        newsType.Status = "ACTIVE";
                        if (newsTypeTableAdapter.Update(newsType) > 0)
                        {
                            Response.Redirect("~/NewsTypes/Default.aspx?GroupID=" + Request["GroupID"]);
                        }
                    }
                    else
                    {
                        Response.Redirect("Login.aspx");
                    }

                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("../NewsTypes/Default.aspx?GroupID=" + Request["GroupID"]);
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
        public string RequestGroupID()
        {
            return Request["GroupID"].ToString();
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
            if (Null.IsNull(txtNewTypeName.Text.Trim()))
            {
                error += GetGlobalResourceObject("NewsTypesResource", "RequireNewTypeName").ToString();
                validData = false;
            }

            if (!validData)
            {
                ShowErrorMessage(error);
            }
            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag").ToString();
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag").ToString();
        }
    }
}
