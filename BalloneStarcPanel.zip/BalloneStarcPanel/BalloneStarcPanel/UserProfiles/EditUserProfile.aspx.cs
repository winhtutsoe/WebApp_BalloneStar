﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Whizzo;
using BalloneStarcPanel.DataAccess;
using BalloneStarcPanel.Entities;
namespace BalloneStarcPanel.UserProfiles
{
    public partial class EditUserProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                    UserRoleTableAdapter userRoleTable = new UserRoleTableAdapter();
                    DataTable dt = userRoleTable.GetDataByStatus("ACTIVE");
                    ddlUserRole.DataTextField = "RoleName";
                    ddlUserRole.DataValueField = "ID";
                    ddlUserRole.DataSource = dt;
                    ddlUserRole.DataBind();

                    UserProfileTableAdapter userTable = new UserProfileTableAdapter();
                    UserProfile user = new UserProfile();
                    user = userTable.GetUserProfileByID(Convert.ToInt32(QueryString.Decode(Request["UserID"])));
                    Session["password"] = user.Password;
                    txtUserName.Text = user.UserName;
                    txtNRCNo.Text = user.NRCNo;
                    txtAddress.Text = user.Address;
                    txtPhone.Text = user.Phone;
                    ddlUserRole.SelectedValue = user.RoleID.ToString();
                }
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                    if (Validation.IsNumber(QueryString.Decode(Request["UserID"])) && Null.IsNotNull(Session["Login"]))
                    {
                        UserProfileTableAdapter userTableAdapter = new UserProfileTableAdapter();
                        UserProfile userData = new UserProfile();
                        userData.ID = Convert.ToInt32(QueryString.Decode(Request["UserID"].ToString()));
                        userData.UserName = StringUtil.EncodeHtml(txtUserName.Text.Trim());
                        userData.Password = Session["password"].ToString();
                        userData.NRCNo = StringUtil.EncodeHtml(txtNRCNo.Text.Trim());
                        userData.Address = StringUtil.EncodeHtml(txtAddress.Text.Trim());
                        userData.Phone = StringUtil.EncodeHtml(txtPhone.Text.Trim());
                        userData.RoleID = Convert.ToInt32(ddlUserRole.SelectedValue);
                        userData.Status = "ACTIVE";
                        if (userTableAdapter.Update(userData) > 0)
                        {
                            Response.Redirect(Config.GetConfig("mainURL") + "Default");
                        }
                    }
                    else
                    {
                        Response.Redirect("Login.aspx");
                    }
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(Config.GetConfig("mainURL") + "Default");
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
        public string RequestGroupID()
        {
            return Request["GroupID"].ToString();
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
            if (Null.IsNull(txtUserName.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireUserName").ToString();
                validData = false;
            }
            if (Null.IsNull(txtNRCNo.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireNRCNo").ToString();
                validData = false;
            }
            if (Null.IsNull(txtAddress.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireAddress").ToString();
                validData = false;
            }
            if (Null.IsNull(txtPhone.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequirePhone").ToString();
                validData = false;
            }
            if (!validData)
            {
                ShowErrorMessage(error);
            }
            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag").ToString();
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag").ToString();
        }
    }
}
