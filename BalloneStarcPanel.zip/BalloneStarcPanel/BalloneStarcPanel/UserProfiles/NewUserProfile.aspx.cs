﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BalloneStarcPanel.Entities;
using BalloneStarcPanel.DataAccess;
using Whizzo;
using Whizzo.Security;
using System.Data;
namespace BalloneStarcPanel.UserProfiles
{
    public partial class NewUserProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {

                    UserRoleTableAdapter userRoleTable = new UserRoleTableAdapter();
                    DataTable dt = userRoleTable.GetDataByStatus("ACTIVE");
                    ddlRoleName.DataValueField = "ID";
                    ddlRoleName.DataTextField = "RoleName";
                    ddlRoleName.DataSource = dt;
                    ddlRoleName.DataBind();
                }
            }
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
            if (Null.IsNull(txtUserName.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireUserName").ToString();
                validData = false;
            }
            if (Null.IsNull(txtPassword.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequirePassword").ToString();
                validData = false;
            }
            if (Null.IsNull(txtConfirmPassword.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireConfirmPassword").ToString();
                validData = false;
            }
            if (Null.IsNotNull(txtPassword.Text.Trim()) && Null.IsNotNull(txtConfirmPassword.Text.Trim()))
            {
                if (!StringUtil.EncodeHtml(txtPassword.Text.Trim()).Equals(StringUtil.EncodeHtml(txtConfirmPassword.Text.Trim())))
                {
                    error += GetGlobalResourceObject("UserProfilesResource", "MustSamePassword").ToString();
                    validData = false;
                }
            }
            if (Null.IsNull(txtNRCNo.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireNRCNo").ToString();
                validData = false;
            }
            if (Null.IsNull(txtAddress.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequireAddress").ToString();
                validData = false;
            }
            if (Null.IsNull(txtPhone.Text.Trim()))
            {
                error += GetGlobalResourceObject("UserProfilesResource", "RequirePhone").ToString();
                validData = false;
            }

            if (!validData)
            {
                ShowErrorMessage(error);
            }
            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag").ToString();
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag").ToString();
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                UserProfileTableAdapter userTable = new UserProfileTableAdapter();
                UserProfile user = new UserProfile();
                user.UserName = StringUtil.EncodeHtml(txtUserName.Text.Trim());
                user.Password = Hash.ToHash(StringUtil.EncodeHtml(txtPassword.Text.Trim()));
                user.NRCNo = StringUtil.EncodeHtml(txtNRCNo.Text.Trim());
                user.Address = StringUtil.EncodeHtml(txtAddress.Text.Trim());
                user.Phone = StringUtil.EncodeHtml(txtPhone.Text.Trim());
                user.RoleID = Convert.ToInt32(ddlRoleName.SelectedValue);
                user.Status = "ACTIVE";
                if (userTable.Insert(user) > 0)
                {
                    Response.Redirect(Config.GetConfig("mainURL") + "Default");
                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(Config.GetConfig("mainURL") + "Default");
        }
    }
}
