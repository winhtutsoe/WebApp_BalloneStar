﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Whizzo;
using BalloneStarcPanel.Entities;
namespace BalloneStarcPanel.DataAccess
{

	public class NewsTableAdapter : BaseDataAdapter
	{
		
		
		#region Constructers

			public NewsTableAdapter():base()
            {
                InitInsertCommand();
                InitUpdateCommand();
                InitDeleteCommand();
                InitCommandCollection();
            }

		#endregion

		

		#region Initializations

		protected  void InitInsertCommand()
		{
			InsertCommand.CommandType = CommandType.Text;
            InsertCommand.Connection = Connection;
			InsertCommand.CommandText = @"INSERT INTO News(NewsCategoryID,NewsTypeID,NewsCategoryName,NewTypeName,Description,HashTag,ImagePath,ReleaseDate,Status) VALUES (@NewsCategoryID,@NewsTypeID,@NewsCategoryName,@NewTypeName,@Description,@HashTag,@ImagePath,@ReleaseDate,@Status);SELECT ID FROM News WHERE (ID = SCOPE_IDENTITY())";
						InsertCommand.Parameters.Add(new SqlParameter("@NewsCategoryID", SqlDbType.Int, 4, ParameterDirection.Input, true, ((Byte)(10)), ((Byte)(0)),"NewsCategoryID", System.Data.DataRowVersion.Current, null));
			InsertCommand.Parameters.Add(new SqlParameter("@NewsTypeID", SqlDbType.Int, 4, ParameterDirection.Input, true, ((Byte)(10)), ((Byte)(0)),"NewsTypeID", System.Data.DataRowVersion.Current, null));
			InsertCommand.Parameters.Add(new SqlParameter("@NewsCategoryName", SqlDbType.NVarChar, 50,"NewsCategoryName"));
			InsertCommand.Parameters.Add(new SqlParameter("@NewTypeName", SqlDbType.NVarChar, 50,"NewTypeName"));
			InsertCommand.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar, -1,"Description"));
			InsertCommand.Parameters.Add(new SqlParameter("@HashTag", SqlDbType.VarChar, 100,"HashTag"));
			InsertCommand.Parameters.Add(new SqlParameter("@ImagePath", SqlDbType.VarChar, 200,"ImagePath"));
			InsertCommand.Parameters.Add(new SqlParameter("@ReleaseDate", SqlDbType.DateTime, 8,"ReleaseDate"));
			InsertCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 10,"Status"));

			
		}

		protected  void InitUpdateCommand()
		{
			UpdateCommand.CommandType = CommandType.Text;
            UpdateCommand.Connection = Connection;
			UpdateCommand.CommandText = @"UPDATE News SET NewsCategoryID = @NewsCategoryID, NewsTypeID = @NewsTypeID, NewsCategoryName = @NewsCategoryName, NewTypeName = @NewTypeName, Description = @Description, HashTag = @HashTag, ImagePath = @ImagePath, ReleaseDate = @ReleaseDate, Status = @Status WHERE (ID = @ID)";
						UpdateCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int, 4, ParameterDirection.Input, false, ((Byte)(10)), ((Byte)(0)), "ID", System.Data.DataRowVersion.Current, null));
			UpdateCommand.Parameters.Add(new SqlParameter("@NewsCategoryID", SqlDbType.Int, 4, ParameterDirection.Input, true, ((Byte)(10)), ((Byte)(0)),"NewsCategoryID", System.Data.DataRowVersion.Current, null));
			UpdateCommand.Parameters.Add(new SqlParameter("@NewsTypeID", SqlDbType.Int, 4, ParameterDirection.Input, true, ((Byte)(10)), ((Byte)(0)),"NewsTypeID", System.Data.DataRowVersion.Current, null));
			UpdateCommand.Parameters.Add(new SqlParameter("@NewsCategoryName", SqlDbType.NVarChar, 50,"NewsCategoryName"));
			UpdateCommand.Parameters.Add(new SqlParameter("@NewTypeName", SqlDbType.NVarChar, 50,"NewTypeName"));
			UpdateCommand.Parameters.Add(new SqlParameter("@Description", SqlDbType.NVarChar, -1,"Description"));
			UpdateCommand.Parameters.Add(new SqlParameter("@HashTag", SqlDbType.VarChar, 100,"HashTag"));
			UpdateCommand.Parameters.Add(new SqlParameter("@ImagePath", SqlDbType.VarChar, 200,"ImagePath"));
			UpdateCommand.Parameters.Add(new SqlParameter("@ReleaseDate", SqlDbType.DateTime, 8,"ReleaseDate"));
			UpdateCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 10,"Status"));

			
		}

		protected  void InitDeleteCommand()
		{
            DeleteCommand.CommandType = CommandType.Text;
			DeleteCommand.Connection = Connection;
			DeleteCommand.CommandText = "DELETE FROM News WHERE (ID = @ID)";
			DeleteCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int, 4, ParameterDirection.Input, false, ((Byte)(10)), ((Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));
		}

		

		protected  void InitCommandCollection()
		{
			CommandCollection = new IDbCommand[3];

			CommandCollection[0] = new SqlCommand();
			((SqlCommand) (CommandCollection[0])).Connection = Connection;
			((SqlCommand) (CommandCollection[0])).CommandText = "SELECT ID,NewsCategoryID,NewsTypeID,NewsCategoryName,NewTypeName,Description,HashTag,ImagePath,ReleaseDate,Status FROM News";
			((SqlCommand) (CommandCollection[0])).CommandType = CommandType.Text;
			
			//Fill/GetByID
            CommandCollection[1] = new SqlCommand();
            ((SqlCommand)(CommandCollection[1])).Connection = this.Connection;
            ((SqlCommand)(CommandCollection[1])).CommandText = "SELECT ID,NewsCategoryID,NewsTypeID,NewsCategoryName,NewTypeName,Description,HashTag,ImagePath,ReleaseDate,Status FROM News WHERE ID =  @ID";
            ((SqlCommand)(CommandCollection[1])).CommandType = CommandType.Text;
            ((SqlCommand)(this.CommandCollection[1])).Parameters.Add(new SqlParameter("@ID", SqlDbType.Int, 4, "ID"));
			
			//Fill/GetByStatus
            CommandCollection[2] = new SqlCommand();
            ((SqlCommand)(CommandCollection[2])).Connection = this.Connection;
            ((SqlCommand)(CommandCollection[2])).CommandText = "SELECT ID,NewsCategoryName,NewTypeName,Description,HashTag,ReleaseDate,Status FROM News WHERE Status =  @Status";
            ((SqlCommand)(CommandCollection[2])).CommandType = CommandType.Text;
            ((SqlCommand)(this.CommandCollection[2])).Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 20, "Status"));
			
			#region CustomCommand
			
			
			
			
			
			#endregion CustomCommand
			
		}

		#endregion

		#region Data Functions

		
		public int Fill(DataTable dt)
		{
           
            int returnValue =-1;
			Adapter.SelectCommand = ((SqlCommand) (this.CommandCollection[0]));
            
			try
            {
                Adapter.SelectCommand.Connection.Open();
			    returnValue = Adapter.Fill(dt);
            }
            catch(SqlException ex)
            {
               // Logger.Write(ex);
            }
            finally
			{
                 Adapter.SelectCommand.Connection.Close();
            }
			return returnValue;
		}

		public DataTable GetData()
		{
           
			Adapter.SelectCommand = ((SqlCommand) (CommandCollection[0]));
			DataTable dt = new DataTable();
            
            try
            {
                Adapter.SelectCommand.Connection.Open();
			    Adapter.Fill(dt);
            }
            catch(SqlException ex)
            {
                //Logger.Write(ex);
            }
            finally
			{
                 Adapter.SelectCommand.Connection.Close();
            }
			
			return dt;
		}
	       public DataTable GetDataByStatus(string status)
        {

            DataTable dt = new DataTable();
            Adapter.SelectCommand = ((SqlCommand)(CommandCollection[2]));
            Adapter.SelectCommand.Parameters["@Status"].Value = status;

            try
            {
                Adapter.SelectCommand.Connection.Open();
                Adapter.Fill(dt);
            }
            catch (SqlException ex)
            {
                // Logger.Write(ex);
            }
            finally
            {
                Adapter.SelectCommand.Connection.Close();
            }

            return dt;
        }

		public News GetNewsByID(int ID)
		{
            
            DataTable dt = new DataTable();
			Adapter.SelectCommand = ((SqlCommand) (CommandCollection[1]));
			Adapter.SelectCommand.Parameters[0].Value = ID;
		   
            try
            {
                Adapter.SelectCommand.Connection.Open();
			    Adapter.Fill(dt);
            }
            catch(SqlException ex)
            {
               // Logger.Write(ex);
            }
            finally
			{
                 Adapter.SelectCommand.Connection.Close();
            }
		
			return DataTableToEntity(dt);
		}
		
		public DataSet GetNewsByStatus(string status)
		{
             DataSet ds = new DataSet();
            Adapter.SelectCommand = ((SqlCommand)(CommandCollection[2]));
            Adapter.SelectCommand.Parameters[0].Value = status;

            try
            {
                Adapter.SelectCommand.Connection.Open();
                Adapter.Fill(ds);
            }
            catch (SqlException ex)
            {
                // Logger.Write(ex);
            }
            finally
            {
                Adapter.SelectCommand.Connection.Close();
            }

            return ds;
		}

		#region CustomGetTable
		
		
		
		
		
		#endregion CustomGetTable
	    
		public int Insert(News news)
		{
	InsertCommand.Parameters["@NewsCategoryID"].Value = news.NewsCategoryID;
	InsertCommand.Parameters["@NewsTypeID"].Value = news.NewsTypeID;
	InsertCommand.Parameters["@NewsCategoryName"].Value = news.NewsCategoryName;
	InsertCommand.Parameters["@NewTypeName"].Value = news.NewTypeName;
	InsertCommand.Parameters["@Description"].Value = news.Description;
	InsertCommand.Parameters["@HashTag"].Value = news.HashTag;
	InsertCommand.Parameters["@ImagePath"].Value = news.ImagePath;
	InsertCommand.Parameters["@ReleaseDate"].Value = news.ReleaseDate;
	InsertCommand.Parameters["@Status"].Value = news.Status;
		
			
            int returnValue = -1;
            try
            {
                InsertCommand.Connection.Open();
                returnValue = (int)InsertCommand.ExecuteScalar();
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                InsertCommand.Connection.Close();
            }
            return returnValue;
		}
        
		public int Update(News news)
		{
	UpdateCommand.Parameters["@ID"].Value = news.ID;
	UpdateCommand.Parameters["@NewsCategoryID"].Value = news.NewsCategoryID;
	UpdateCommand.Parameters["@NewsTypeID"].Value = news.NewsTypeID;
	UpdateCommand.Parameters["@NewsCategoryName"].Value = news.NewsCategoryName;
	UpdateCommand.Parameters["@NewTypeName"].Value = news.NewTypeName;
	UpdateCommand.Parameters["@Description"].Value = news.Description;
	UpdateCommand.Parameters["@HashTag"].Value = news.HashTag;
	UpdateCommand.Parameters["@ImagePath"].Value = news.ImagePath;
	UpdateCommand.Parameters["@ReleaseDate"].Value = news.ReleaseDate;
	UpdateCommand.Parameters["@Status"].Value = news.Status;

			int returnValue = -1;
            try
            {
                UpdateCommand.Connection.Open();
                returnValue = UpdateCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                UpdateCommand.Connection.Close();
            }
            return returnValue;
		}
        
        private News DataTableToEntity(DataTable dt)
        {
           
            News news = new News();
            if(Null.IsNotNull(dt)==true && dt.Rows.Count > 0)
            {
                
                if (Null.IsNotNull(dt.Rows[0]))
                {
                    DataRow dr = dt.Rows[0];
                      					if (Null.IsNotNull(dr["ID"]))
					{
						news.ID=Convert.ToInt32(dr["ID"]);
					}
					else
					{
						news.ID=0;
					}
					if (Null.IsNotNull(dr["NewsCategoryID"]))
					{
						news.NewsCategoryID=Convert.ToInt32(dr["NewsCategoryID"]);
					}
					else
					{
						news.NewsCategoryID=0;
					}
					if (Null.IsNotNull(dr["NewsTypeID"]))
					{
						news.NewsTypeID=Convert.ToInt32(dr["NewsTypeID"]);
					}
					else
					{
						news.NewsTypeID=0;
					}
					if (Null.IsNotNull(dr["NewsCategoryName"]))
					{
						news.NewsCategoryName= Convert.ToString(dr["NewsCategoryName"]);
					}
					else
					{
						news.NewsCategoryName=string.Empty;
					}
					if (Null.IsNotNull(dr["NewTypeName"]))
					{
						news.NewTypeName= Convert.ToString(dr["NewTypeName"]);
					}
					else
					{
						news.NewTypeName=string.Empty;
					}
					if (Null.IsNotNull(dr["Description"]))
					{
						news.Description= Convert.ToString(dr["Description"]);
					}
					else
					{
						news.Description=string.Empty;
					}
					if (Null.IsNotNull(dr["HashTag"]))
					{
						news.HashTag= Convert.ToString(dr["HashTag"]);
					}
					else
					{
						news.HashTag=string.Empty;
					}
					if (Null.IsNotNull(dr["ImagePath"]))
					{
						news.ImagePath= Convert.ToString(dr["ImagePath"]);
					}
					else
					{
						news.ImagePath=string.Empty;
					}
					if (Null.IsNotNull(dr["ReleaseDate"]))
					{
						news.ReleaseDate= Convert.ToDateTime(dr["ReleaseDate"]);
					}
					else
					{
						news.ReleaseDate=DateTime.Now;
					}
					if (Null.IsNotNull(dr["Status"]))
					{
						news.Status= Convert.ToString(dr["Status"]);
					}
					else
					{
						news.Status=string.Empty;
					}
 
                }
            }
            return news ;
        }
		#endregion		
	}
}