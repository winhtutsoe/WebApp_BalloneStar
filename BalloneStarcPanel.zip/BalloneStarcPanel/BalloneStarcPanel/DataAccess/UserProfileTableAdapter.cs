﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Whizzo;
using BalloneStarcPanel.Entities;


namespace BalloneStarcPanel.DataAccess
{

    public class UserProfileTableAdapter : BaseDataAdapter
    {


        #region Constructers

        public UserProfileTableAdapter()
            : base()
        {
            InitInsertCommand();
            InitUpdateCommand();
            InitDeleteCommand();
            InitCommandCollection();
        }

        #endregion



        #region Initializations

        protected void InitInsertCommand()
        {
            InsertCommand.CommandType = CommandType.Text;
            InsertCommand.Connection = Connection;
            InsertCommand.CommandText = @"INSERT INTO UserProfile(UserName,Password,NRCNo,Address,Phone,OTPKey,ImageURL,RoleID,Status) VALUES (@UserName,@Password,@NRCNo,@Address,@Phone,@OTPKey,@ImageURL,@RoleID,@Status);SELECT ID FROM UserProfile WHERE (ID = SCOPE_IDENTITY())";
            InsertCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar, 50, "UserName"));
            InsertCommand.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50, "Password"));
            InsertCommand.Parameters.Add(new SqlParameter("@NRCNo", SqlDbType.VarChar, 50, "NRCNo"));
            InsertCommand.Parameters.Add(new SqlParameter("@Address", SqlDbType.VarChar, 200, "Address"));
            InsertCommand.Parameters.Add(new SqlParameter("@Phone", SqlDbType.VarChar, 100, "Phone"));
            InsertCommand.Parameters.Add(new SqlParameter("@OTPKey", SqlDbType.VarChar, 300, "OTPKey"));
            InsertCommand.Parameters.Add(new SqlParameter("@ImageURL", SqlDbType.VarChar, 200, "ImageURL"));
            InsertCommand.Parameters.Add(new SqlParameter("@RoleID", SqlDbType.Int, 4, ParameterDirection.Input, true, ((Byte)(10)), ((Byte)(0)), "RoleID", System.Data.DataRowVersion.Current, null));
            InsertCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 10, "Status"));

        }

        protected void InitUpdateCommand()
        {
            UpdateCommand.CommandType = CommandType.Text;
            UpdateCommand.Connection = Connection;
            UpdateCommand.CommandText = @"UPDATE UserProfile SET UserName = @UserName, Password = @Password, NRCNo = @NRCNo, Address = @Address, Phone = @Phone, OTPKey = @OTPKey, ImageURL = @ImageURL, RoleID = @RoleID, Status = @Status WHERE (ID = @ID)";
            UpdateCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int, 4, ParameterDirection.Input, false, ((Byte)(10)), ((Byte)(0)), "ID", System.Data.DataRowVersion.Current, null));
            UpdateCommand.Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar, 50, "UserName"));
            UpdateCommand.Parameters.Add(new SqlParameter("@Password", SqlDbType.VarChar, 50, "Password"));
            UpdateCommand.Parameters.Add(new SqlParameter("@NRCNo", SqlDbType.VarChar, 50, "NRCNo"));
            UpdateCommand.Parameters.Add(new SqlParameter("@Address", SqlDbType.VarChar, 200, "Address"));
            UpdateCommand.Parameters.Add(new SqlParameter("@Phone", SqlDbType.VarChar, 100, "Phone"));
            UpdateCommand.Parameters.Add(new SqlParameter("@OTPKey", SqlDbType.VarChar, 300, "OTPKey"));
            UpdateCommand.Parameters.Add(new SqlParameter("@ImageURL", SqlDbType.VarChar, 200, "ImageURL"));
            UpdateCommand.Parameters.Add(new SqlParameter("@RoleID", SqlDbType.Int, 4, ParameterDirection.Input, true, ((Byte)(10)), ((Byte)(0)), "RoleID", System.Data.DataRowVersion.Current, null));
            UpdateCommand.Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 10, "Status"));

        }

        protected void InitDeleteCommand()
        {
            DeleteCommand.CommandType = CommandType.Text;
            DeleteCommand.Connection = Connection;
            DeleteCommand.CommandText = "DELETE FROM UserProfile WHERE (ID = ID)";
            DeleteCommand.Parameters.Add(new SqlParameter("@ID", SqlDbType.Int, 4, ParameterDirection.Input, false, ((Byte)(10)), ((Byte)(0)), "ID", System.Data.DataRowVersion.Original, null));

        }



        protected void InitCommandCollection()
        {
            CommandCollection = new IDbCommand[4];

            CommandCollection[0] = new SqlCommand();
            ((SqlCommand)(CommandCollection[0])).Connection = Connection;
            ((SqlCommand)(CommandCollection[0])).CommandText = "SELECT ID,UserName,Password,NRCNo,Address,Phone,OTPKey,ImageURL,RoleID,Status FROM UserProfile";
            ((SqlCommand)(CommandCollection[0])).CommandType = CommandType.Text;

            //Fill/GetByID
            CommandCollection[1] = new SqlCommand();
            ((SqlCommand)(CommandCollection[1])).Connection = this.Connection;
            ((SqlCommand)(CommandCollection[1])).CommandText = "SELECT ID,UserName,Password,NRCNo,Address,Phone,OTPKey,ImageURL,RoleID,Status FROM UserProfile WHERE ID =  @ID";
            ((SqlCommand)(CommandCollection[1])).CommandType = CommandType.Text;
            ((SqlCommand)(this.CommandCollection[1])).Parameters.Add(new SqlParameter("@ID", SqlDbType.Int, 4, "ID"));

            CommandCollection[2] = new SqlCommand();
            ((SqlCommand)(CommandCollection[2])).Connection = this.Connection;
            ((SqlCommand)(CommandCollection[2])).CommandText = "SELECT UserProfile.ID,UserName,Password,NRCNo,Address,Phone,OTPKey,ImageURL,RoleName,UserProfile.Status FROM UserProfile,UserRole WHERE UserProfile.RoleID=UserRole.ID AND UserProfile.Status =  @Status";
            ((SqlCommand)(CommandCollection[2])).CommandType = CommandType.Text;
            ((SqlCommand)(this.CommandCollection[2])).Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 20, "Status"));

            CommandCollection[3] = new SqlCommand();
            ((SqlCommand)(CommandCollection[3])).Connection = this.Connection;
            ((SqlCommand)(CommandCollection[3])).CommandText = "SELECT ID,UserName,Password,NRCNo,Address,Phone,OTPKey,ImageURL,RoleID,Status FROM UserProfile WHERE UserName =  @UserName AND Status=@Status";
            ((SqlCommand)(CommandCollection[3])).CommandType = CommandType.Text;
            ((SqlCommand)(this.CommandCollection[3])).Parameters.Add(new SqlParameter("@UserName", SqlDbType.VarChar, 50, "UserName"));
            ((SqlCommand)(this.CommandCollection[3])).Parameters.Add(new SqlParameter("@Status", SqlDbType.VarChar, 20, "Status"));
        }

        #endregion

        #region Data Functions


        public int Fill(DataTable dt)
        {

            int returnValue = -1;
            Adapter.SelectCommand = ((SqlCommand)(this.CommandCollection[0]));

            try
            {
                Adapter.SelectCommand.Connection.Open();
                returnValue = Adapter.Fill(dt);
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                Adapter.SelectCommand.Connection.Close();
            }
            return returnValue;
        }

        public DataTable GetData()
        {

            Adapter.SelectCommand = ((SqlCommand)(CommandCollection[0]));
            DataTable dt = new DataTable();

            try
            {
                Adapter.SelectCommand.Connection.Open();
                Adapter.Fill(dt);
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                Adapter.SelectCommand.Connection.Close();
            }

            return dt;
        }


        public UserProfile GetUserProfileByID(int ID)
        {

            DataTable dt = new DataTable();
            Adapter.SelectCommand = ((SqlCommand)(CommandCollection[1]));
            Adapter.SelectCommand.Parameters[0].Value = ID;

            try
            {
                Adapter.SelectCommand.Connection.Open();
                Adapter.Fill(dt);
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                Adapter.SelectCommand.Connection.Close();
            }

            return DataTableToEntity(dt);
        }

        public DataSet GetEmployeeByStatus(string status)
        {

            DataSet ds = new DataSet();
            Adapter.SelectCommand = ((SqlCommand)(CommandCollection[2]));
            Adapter.SelectCommand.Parameters[0].Value = status;

            try
            {
                Adapter.SelectCommand.Connection.Open();
                Adapter.Fill(ds);
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                Adapter.SelectCommand.Connection.Close();
            }

            return ds;
        }
        public UserProfile GetEmployeeByName(string UserName, string Status)
        {

            DataTable dt = new DataTable();
            Adapter.SelectCommand = ((SqlCommand)(CommandCollection[3]));
            Adapter.SelectCommand.Parameters["@UserName"].Value = UserName;
            Adapter.SelectCommand.Parameters["@Status"].Value = Status;

            try
            {
                Adapter.SelectCommand.Connection.Open();
                Adapter.Fill(dt);
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                Adapter.SelectCommand.Connection.Close();
            }

            return DataTableToEntity(dt);
        }
        public int Insert(UserProfile userProfile)
        {
            InsertCommand.Parameters["@UserName"].Value = userProfile.UserName;
            InsertCommand.Parameters["@Password"].Value = userProfile.Password;
            InsertCommand.Parameters["@NRCNo"].Value = userProfile.NRCNo;
            InsertCommand.Parameters["@Address"].Value = userProfile.Address;
            InsertCommand.Parameters["@Phone"].Value = userProfile.Phone;
            InsertCommand.Parameters["@OTPKey"].Value = userProfile.OTPKey;
            InsertCommand.Parameters["@ImageURL"].Value = userProfile.ImageURL;
            InsertCommand.Parameters["@RoleID"].Value = userProfile.RoleID;
            InsertCommand.Parameters["@Status"].Value = userProfile.Status;


            int returnValue = -1;
            try
            {
                InsertCommand.Connection.Open();
                returnValue = (int)InsertCommand.ExecuteScalar();
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                InsertCommand.Connection.Close();
            }
            return returnValue;
        }

        public int Update(UserProfile userProfile)
        {
            UpdateCommand.Parameters["@ID"].Value = userProfile.ID;
            UpdateCommand.Parameters["@UserName"].Value = userProfile.UserName;
            UpdateCommand.Parameters["@Password"].Value = userProfile.Password;
            UpdateCommand.Parameters["@NRCNo"].Value = userProfile.NRCNo;
            UpdateCommand.Parameters["@Address"].Value = userProfile.Address;
            UpdateCommand.Parameters["@Phone"].Value = userProfile.Phone;
            UpdateCommand.Parameters["@OTPKey"].Value = userProfile.OTPKey;
            UpdateCommand.Parameters["@ImageURL"].Value = userProfile.ImageURL;
            UpdateCommand.Parameters["@RoleID"].Value = userProfile.RoleID;
            UpdateCommand.Parameters["@Status"].Value = userProfile.Status;

            int returnValue = -1;
            try
            {
                UpdateCommand.Connection.Open();
                returnValue = UpdateCommand.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                Logger.Write(ex);
            }
            finally
            {
                UpdateCommand.Connection.Close();
            }
            return returnValue;
        }

        private UserProfile DataTableToEntity(DataTable dt)
        {

            UserProfile userProfile = new UserProfile();
            if (Null.IsNotNull(dt) == true && dt.Rows.Count > 0)
            {

                if (Null.IsNotNull(dt.Rows[0]))
                {
                    DataRow dr = dt.Rows[0];
                    if (Null.IsNotNull(dr["ID"]))
                    {
                        userProfile.ID = Convert.ToInt32(dr["ID"]);
                    }
                    else
                    {
                        userProfile.ID = 0;
                    }
                    if (Null.IsNotNull(dr["UserName"]))
                    {
                        userProfile.UserName = Convert.ToString(dr["UserName"]);
                    }
                    else
                    {
                        userProfile.UserName = string.Empty;
                    }
                    if (Null.IsNotNull(dr["Password"]))
                    {
                        userProfile.Password = Convert.ToString(dr["Password"]);
                    }
                    else
                    {
                        userProfile.Password = string.Empty;
                    }
                    if (Null.IsNotNull(dr["NRCNo"]))
                    {
                        userProfile.NRCNo = Convert.ToString(dr["NRCNo"]);
                    }
                    else
                    {
                        userProfile.NRCNo = string.Empty;
                    }
                    if (Null.IsNotNull(dr["Address"]))
                    {
                        userProfile.Address = Convert.ToString(dr["Address"]);
                    }
                    else
                    {
                        userProfile.Address = string.Empty;
                    }
                    if (Null.IsNotNull(dr["Phone"]))
                    {
                        userProfile.Phone = Convert.ToString(dr["Phone"]);
                    }
                    else
                    {
                        userProfile.Phone = string.Empty;
                    }
                    if (Null.IsNotNull(dr["OTPKey"]))
                    {
                        userProfile.OTPKey = Convert.ToString(dr["OTPKey"]);
                    }
                    else
                    {
                        userProfile.OTPKey = string.Empty;
                    }
                    if (Null.IsNotNull(dr["ImageURL"]))
                    {
                        userProfile.ImageURL = Convert.ToString(dr["ImageURL"]);
                    }
                    else
                    {
                        userProfile.ImageURL = string.Empty;
                    }
                    if (Null.IsNotNull(dr["RoleID"]))
                    {
                        userProfile.RoleID = Convert.ToInt32(dr["RoleID"]);
                    }
                    else
                    {
                        userProfile.RoleID = 0;
                    }
                    if (Null.IsNotNull(dr["Status"]))
                    {
                        userProfile.Status = Convert.ToString(dr["Status"]);
                    }
                    else
                    {
                        userProfile.Status = string.Empty;
                    }
                }
            }
            return userProfile;
        }
        #endregion
    }
}



