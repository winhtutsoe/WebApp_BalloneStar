﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Whizzo;
using BalloneStarcPanel.DataAccess;
using BalloneStarcPanel.Entities;
namespace BalloneStarcPanel.Advertisments
{
    public partial class DeleteAdvertisment : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
        public string RequestGroupID()
        {
            return Request["GroupID"].ToString();
        }
        protected void btnYes_Click(object sender, EventArgs e)
        {
            if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
            {
                AdvertismentTableAdapter advertismentTableAdapter = new AdvertismentTableAdapter();
Advertisment advertisment = new Advertisment();
advertisment = advertismentTableAdapter.GetAdvertismentByID(Convert.ToInt32(QueryString.Decode(Request["AdvertismentID"])));
advertisment.Status = "INACTIVE";
if (advertismentTableAdapter.Update(advertisment) > 0)
{
Response.Redirect("../Advertisments/Default.aspx?GroupID=" + Request["GroupID"]);
}

            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Advertisments/Default.aspx?GroupID=" + Request["GroupID"]);
        }
    }
}
