﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Whizzo;
using BalloneStarcPanel.DataAccess;
using BalloneStarcPanel.Entities;
namespace BalloneStarcPanel.Newses
{
    public partial class DeleteNews : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
        public string RequestGroupID()
        {
            return Request["GroupID"].ToString();
        }
        protected void btnYes_Click(object sender, EventArgs e)
        {
            if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
            {
                NewsTableAdapter newsTableAdapter = new NewsTableAdapter();
News news = new News();
news = newsTableAdapter.GetNewsByID(Convert.ToInt32(QueryString.Decode(Request["NewsID"])));
news.Status = "INACTIVE";
if (newsTableAdapter.Update(news) > 0)
{
Response.Redirect("../Newses/Default.aspx?GroupID=" + Request["GroupID"]);
}

            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Newses/Default.aspx?GroupID=" + Request["GroupID"]);
        }
    }
}
