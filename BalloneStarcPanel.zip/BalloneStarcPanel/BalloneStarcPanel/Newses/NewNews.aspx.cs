﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Whizzo;
using BalloneStarcPanel.Entities;
using BalloneStarcPanel.DataAccess;
using Whizzo.Security;
using System.IO;
namespace BalloneStarcPanel.Newses
{
    public partial class NewNews : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                    NewsCategoryTableAdapter newsCategoryTableAdapter = new NewsCategoryTableAdapter();
                    DataTable dtNewsCategory = newsCategoryTableAdapter.GetDataByStatus("ACTIVE");
                    ddlNewsCategory.DataValueField = "ID";
                    ddlNewsCategory.DataTextField = "NewsCategoryName";
                    ddlNewsCategory.DataSource = dtNewsCategory;
                    ddlNewsCategory.DataBind();

                    NewsTypeTableAdapter newsTypeTableAdapter = new NewsTypeTableAdapter();
                    DataTable dtNewsType = newsTypeTableAdapter.GetDataByStatus("ACTIVE");
                    ddlNewsType.DataValueField = "ID";
                    ddlNewsType.DataTextField = "NewsTypeName";
                    ddlNewsType.DataSource = dtNewsType;
                    ddlNewsType.DataBind();

                }
         
            }
        }

        protected void PersonalFileSizeValidator_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (UploadImage.FileBytes.Length > (1024 * 1024))
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }

        }


        private void UploadFile(string filename)
        {
            try
            {

                String strFile = System.IO.Path.GetFileName(filename);

//
               // BalloneStarcPanel.ImageUploader.ImageUploaderService srv = new BalloneStarcPanel.ImageUploader.ImageUploaderService();

                FileInfo fInfo = new FileInfo(filename);

                long numBytes = fInfo.Length;
                double dLen = Convert.ToDouble(fInfo.Length / 1000000);


                if (dLen < 4)
                {

                    FileStream fStream = new FileStream(filename, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fStream);


                    byte[] data = br.ReadBytes((int)numBytes);
                    br.Close();


                   // string sTmp = srv.UploadFile(data, strFile);
                    fStream.Close();
                    fStream.Dispose();

                }
                else
                {

                    ltlErrorMessage.Text = "The file selected exceeds the size limit for uploads.File Size";
                }
            }
            catch (Exception ex)
            {
                Logger.Write(ex);
            }
        }


        public string SaveUploadFile(FileUpload fuSave)
        {
            string savePath = Server.MapPath("~/Image/");
            string uniqueFileName = Guid.NewGuid().ToString();
            string filename = uniqueFileName + Path.GetExtension(fuSave.FileName);
            savePath = savePath + filename;
            fuSave.SaveAs(savePath);
            UploadFile(savePath);
            return filename;

        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                NewsTableAdapter newsTableAdapter = new NewsTableAdapter();
                News news = new News();
                news.NewsCategoryID = Convert.ToInt32(ddlNewsCategory.SelectedValue);
                news.NewsTypeID = Convert.ToInt32(ddlNewsType.SelectedValue);
                news.NewsCategoryName = StringUtil.EncodeHtml(ddlNewsCategory.Text.Trim());
                news.NewTypeName = StringUtil.EncodeHtml(ddlNewsType.Text.Trim());
                news.Description = StringUtil.EncodeHtml(txtDescription.Text.Trim());
                news.HashTag = StringUtil.EncodeHtml(txtHashTag.Text.Trim());
               // news.ImagePath = StringUtil.EncodeHtml(ImagePath.FileName);
                news.Status = "ACTIVE";
                if (newsTableAdapter.Insert(news) > 0)
                {
                    Response.Redirect("~/Newses/Default.aspx?GroupID=" + Request["GroupID"]);
                }

            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("../Newses/Default.aspx?GroupID=" + Request["GroupID"]);
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
           
            if (Null.IsNull(txtDescription.Text.Trim()))
            {
                error += GetGlobalResourceObject("NewsesResource", "RequireDescription").ToString();
                validData = false;
            }
            if (Null.IsNull(txtHashTag.Text.Trim()))
            {
                error += GetGlobalResourceObject("NewsesResource", "RequireHashTag").ToString();
                validData = false;
            }

            if (!validData)
            {
                ShowErrorMessage(error);
            }
            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag").ToString();
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag").ToString();
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }

        protected void lkbtnImage_Click(object sender, EventArgs e)
        {

        }

        protected void lkbtnRemoveImage_Click(object sender, EventArgs e)
        {

        }
    }
}
