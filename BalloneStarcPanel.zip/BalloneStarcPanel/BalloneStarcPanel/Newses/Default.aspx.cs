﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Whizzo;
using BalloneStarcPanel.Entities;
using BalloneStarcPanel.DataAccess;
using BalloneStarcPanel.Controls;
namespace BalloneStarcPanel.Newses
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Request["q"]))
                {
                    if (Null.IsNotNull(Session["Login"].ToString()))
                    {
                        Session["Login"] = null;
                        Session["Name"] = null;
                        Response.Redirect("~/login.aspx");
                    }
                }
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
					NewsTableAdapter newsTableAdapter = new NewsTableAdapter();
DataSet ds = newsTableAdapter.GetNewsByStatus("ACTIVE");
if (ds.Tables[0].Rows.Count > 0)
{
Session["dt"] = ds.Tables[0];
PagingDataBind();
}

                }
            }
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
        public string RequestGroupID()
        {
            return Request["GroupID"].ToString();
        }
        public string Encode(object query)
        {
            return QueryString.Encode(query.ToString());
        }
        public void Pager1_Change(object sender, PagerEventArgs e)
        {
            PagingDataBind();
        }
        void PagingDataBind()
        {
            DataTable itemdt = new DataTable();
            if (Null.IsNotNull(Session["dt"]))
            {
                itemdt = (DataTable)Session["dt"];
                if (Null.IsNotNull(itemdt) && itemdt.Rows.Count > 0)
                {
                    Pager1.DataSource = itemdt;
                    Pager1.DataBind();

                    if (itemdt.Rows.Count > Pager1.PageSize)
                    {
                        Pager1.Visible = true;
                    }
                    else
                    {
                        Pager1.Visible = false;
                    }
                }
                else
                {
                    Pager1.Visible = false;
                }
            }
        }
    }
}
