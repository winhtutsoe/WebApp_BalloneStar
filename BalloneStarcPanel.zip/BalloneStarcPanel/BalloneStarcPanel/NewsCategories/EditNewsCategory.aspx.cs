﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using Whizzo;
using BalloneStarcPanel.Entities;
using BalloneStarcPanel.DataAccess;
namespace BalloneStarcPanel.NewsCategories
{
    public partial class EditNewsCategory : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ltlErrorMessage.Text = null;
            if (!Page.IsPostBack)
            {
                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {


                    NewsCategoryTableAdapter newsCategoryTableAdapter = new NewsCategoryTableAdapter();
                    NewsCategory newsCategory = new NewsCategory();
                    newsCategory = newsCategoryTableAdapter.GetNewsCategoryByID(Convert.ToInt32(QueryString.Decode(Request["NewsCategoryID"])));
                    txtNewTypeName.Text = newsCategory.NewsCategoryName;


                }
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {

                if (Null.IsNotNull(Session["Login"]) || Null.IsNotNull(Session["Name"]))
                {
                    if (Validation.IsNumber(QueryString.Decode(Request["NewsCategoryID"])) && Null.IsNotNull(Session["Login"]))
                    {
                        NewsCategoryTableAdapter newsCategoryTableAdapter = new NewsCategoryTableAdapter();
                        NewsCategory newsCategory = new NewsCategory();
                        newsCategory.ID = Convert.ToInt32(QueryString.Decode(Request["NewsCategoryID"].ToString()));
                        newsCategory.NewsCategoryName = StringUtil.EncodeHtml(txtNewTypeName.Text.Trim());
                        newsCategory.Status = "ACTIVE";
                        if (newsCategoryTableAdapter.Update(newsCategory) > 0)
                        {
                            Response.Redirect("~/NewsCategories/Default.aspx?GroupID=" + Request["GroupID"]);
                        }
                    }
                    else
                    {
                        Response.Redirect("Login.aspx");
                    }

                }
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("../NewsCategories/Default.aspx?GroupID=" + Request["GroupID"]);
        }
        public string RequestDefaultLink()
        {
            return Config.GetConfig("mainURL") + "Default";
        }
        public string RequestGroupID()
        {
            return Request["GroupID"].ToString();
        }
        public bool IsValidData()
        {
            string error = "";
            bool validData = true;
            if (Null.IsNull(txtNewTypeName.Text.Trim()))
            {
                error += GetGlobalResourceObject("NewsCategoriesResource", "RequireNewTypeName").ToString();
                validData = false;
            }

            if (!validData)
            {
                ShowErrorMessage(error);
            }
            return validData;
        }
        public void ShowErrorMessage(string error)
        {
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageOpenTag").ToString();
            ltlErrorMessage.Text += error;
            ltlErrorMessage.Text += GetGlobalResourceObject("GlobalResources", "ErrorMessageCloseTag").ToString();
        }
    }
}
