﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BalloneStarKeyGenerator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

         public static int GetCurrentThreadId()
         {
                return Process.GetCurrentProcess().Threads.OfType<ProcessThread>().SingleOrDefault(x => x.ThreadState == System.Diagnostics.ThreadState.Running).Id;
         }
        

        //public  int get_SystemStatus_W32(Byte buf, int maxlen)
        //{
        //    int ni = 0;
        //    DWORD dwRes;
        //    MEMORYSTATUS ms;
        //    dwRes = GetCurrentProcessId();
        //    if (maxlen >= sizeof(DWORD))
        //    {
        //        memcpy(&buf[ni], (POINTER) & dwRes, sizeof(dwRes));
        //        ni += sizeof(dwRes);
        //        maxlen -= sizeof(dwRes);
        //    }
        //    dwRes = GetCurrentThreadId();
        //    if (maxlen >= sizeof(DWORD))
        //    {
        //        memcpy(&buf[ni], (POINTER) & dwRes, sizeof(dwRes));
        //        ni += sizeof(dwRes);
        //        maxlen -= sizeof(dwRes);
        //    }
        //    dwRes = GetTickCount();
        //    if (maxlen >= sizeof(DWORD))
        //    {
        //        memcpy(&buf[ni], (POINTER) & dwRes, sizeof(dwRes));
        //        ni += sizeof(dwRes);
        //        maxlen -= sizeof(dwRes);
        //    }
        //    ms.dwLength = sizeof(MEMORYSTATUS);
        //    GlobalMemoryStatus(&ms);
        //    if (maxlen >= sizeof(MEMORYSTATUS))
        //    {
        //        memcpy(&buf[ni], (POINTER) & ms, sizeof(MEMORYSTATUS));
        //        ni += sizeof(MEMORYSTATUS);
        //        maxlen -= sizeof(MEMORYSTATUS);
        //    }
        //    return ni;
        //}

        private void btnGenerate_Click(object sender, EventArgs e)
        {

            textBox1.Text = "ProcessID : " + GetCurrentProcessID().ToString() + "\r\n" + "TrickCount:" + Environment.TickCount.ToString() + "\r\nThreadID=" + GetCurrentThreadId().ToString()+"\r\n"+"MemoryStatus:"+MemoryStatus();

            textBox1.Text = GetCurrentProcessID().ToString() + Environment.TickCount.ToString("####") + GetCurrentThreadId().ToString()+MemoryStatus();
        }

        private System.Int32 CompTime;


        public string MemoryStatus()
        {
          long memory = GC.GetTotalMemory(true);

          return memory.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CompTime = Environment.TickCount;
        }

        public static  int GetCurrentProcessID()
        {
            int nProcessID = Process.GetCurrentProcess().Id;

            return nProcessID;
        }

        public string  timer1_Tick(object sender, EventArgs e)
        {
            long CurTickValue = Environment.TickCount;
            long Difference = CurTickValue - CompTime;


            string str = CurTickValue.ToString();
            return str;
        }
    }
}
