﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace BalloneStarKeyGenerator
{
       class MemoryRead
        {
            const int PROCESS_VM_WRITE = 0x0020;
            const int PROCESS_VM_OPERATION = 0x0008;

            [DllImport("kernel32.dll")]
            public static extern IntPtr OpenProcess(int dwDesiredAccess,
                   bool bInheritHandle, int dwProcessId);

            [DllImport("kernel32.dll", SetLastError = true)]
            static extern bool WriteProcessMemory(int hProcess, int lpBaseAddress,
              byte[] lpBuffer, int dwSize, ref int lpNumberOfBytesWritten);

            public string  Status()
            {
                Process process = Process.GetProcessesByName("notepad")[0];
                IntPtr processHandle = OpenProcess(0x1F0FFF, false, process.Id);

                int bytesWritten = 0;
                byte[] buffer = Encoding.Unicode.GetBytes("It works!\0");
                // '\0' marks the end of string

                // replace 0x0046A3B8 with your address
                return WriteProcessMemory((int)processHandle, 0x0046A3B8, buffer, buffer.Length, ref bytesWritten).ToString();

                
            }

       
    }
}
